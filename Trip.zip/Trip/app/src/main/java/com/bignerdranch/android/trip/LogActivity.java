package com.bignerdranch.android.trip;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import Data.DatabaseHandler;
import Model.TravelTrips;

public class LogActivity extends AppCompatActivity {

    private EditText title;
    private EditText date;
    private EditText triptype,duration,comment,destination;
    private Button save,cancel;

private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

        title=(EditText)findViewById(R.id.TitleText);
        date=(EditText)findViewById(R.id.editDateText);
        triptype=(EditText)findViewById((R.id.editTripTypeText));
        duration=(EditText)findViewById(R.id.editDurationText);
        comment=(EditText)findViewById(R.id.editCommentText);
        destination=(EditText)findViewById(R.id.editDestinationText);
        save=(Button)findViewById(R.id.saveButton);
        cancel=(Button)findViewById(R.id.cancelButton);
        
        
        db= new DatabaseHandler(LogActivity.this);
        
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTrips();
            }
        });

cancel.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        canceltrips();
    }
});


    }

    private void canceltrips() {
        title.setText("");
        date.setText("");
        triptype.setText("");
        destination.setText("");
        duration.setText("");
        comment.setText("");

        //to go to main activity after saving
        Intent intent = new Intent(LogActivity.this,MainActivity.class);
        startActivity(intent);
    }



    private void addTrips() {
        TravelTrips trips = new TravelTrips();

        trips.setTitle(title.getText().toString().trim());
        trips.setDate(date.getText().toString().trim());
        trips.setTripType(triptype.getText().toString().trim());
        trips.setDestination(destination.getText().toString().trim());
        trips.setDuration(duration.getText().toString().trim());
        trips.setComment(comment.getText().toString().trim());

        db.addTrips(trips);
        db.close();

        //clear form after adding
        title.setText("");
        date.setText("");
        triptype.setText("");
        destination.setText("");
        duration.setText("");
        comment.setText("");

        //to go to main activity after saving
        Intent intent = new Intent(LogActivity.this,MainActivity.class);
        startActivity(intent);
    }

}
