package com.bignerdranch.android.trip;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import Data.DatabaseHandler;

public class details extends AppCompatActivity {

    private Button delete;
    private TextView title,date,content;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        title=(TextView)findViewById(R.id.textView1);
        date=(TextView)findViewById(R.id.textView3);
        content=(TextView)findViewById(R.id.textView2);
        delete=(Button)findViewById(R.id.delete);

        Bundle extras =getIntent().getExtras();

        if(extras!=null){
            title.setText(extras.getString("Title"));   //"title" is the key that is got from the previous activity which is DisplayWish
            date.setText("Created" +extras.get("Date"));
            content.setText("\"" + extras.get("Content") +"\"");

            final int id= extras.getInt("id");

            delete.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View v) {
                    DatabaseHandler dba = new DatabaseHandler(getApplicationContext());
                    dba.deleteTrip(id);

                    Toast.makeText(getApplicationContext(),"Trip Deleted",Toast.LENGTH_LONG).show();

                    startActivity(new Intent(details.this,MainActivity.class));
                }
            });
        }
    }
}





