package com.bignerdranch.android.trip;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import Data.DatabaseHandler;
import Model.Settings;
import Model.TravelTrips;

public class settings extends AppCompatActivity {

    private EditText name,ID,email,gender,comment;
    private Button save;
    private DatabaseHandler db;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        name= (EditText)findViewById(R.id.editText);
        ID= (EditText)findViewById(R.id.editText2);
        email=(EditText)findViewById(R.id.editText3);
        gender=(EditText)findViewById(R.id.editText4);
        comment=(EditText)findViewById(R.id.editText5);


        db= new DatabaseHandler(settings.this);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });


    }

    private void save() {
        Settings travels = new Settings();

        travels.setName(name.getText().toString().trim());
        travels.setEmail(email.getText().toString().trim());
        travels.setGender(gender.getText().toString().trim());
        travels.setComment(comment.getText().toString().trim());

        db.addTravels(travels);
        db.close();

        //clear form after adding
        name.setText("");
        ID.setText("");
        email.setText("");
        gender.setText("");
        comment.setText("");

        //to go to main activity after saving
        Intent intent = new Intent(settings.this,MainActivity.class);
        startActivity(intent);
    }

}





